import { associa } from './utilitario.js'


associa("#cresce", elementoCentral)
associa("#diminui", elementoCentral)
associa("#circular", elementoCentral)
associa("#quadriculado", elementoCentral)
associa("#novo", elementoCentral)
