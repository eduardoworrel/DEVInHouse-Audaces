export function soma(valor1,valor2){
    return valor1 + valor2;
}
export const subtrai = (valor1,valor2) => valor1 - valor2